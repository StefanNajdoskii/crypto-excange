// function checkUser() {
//   const savedUser = localStorage.getItem('username');
//   if (savedUser) {
//     document.getElementById('usernameDisplay').innerText = `Dobredojte, ${savedUser}!`;
//   }
// }
// checkUser();

// LOGIN FUNKCIJA
async function loginUser() {
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;

  try {
    const response = await fetch('/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    });

    if (response.ok) {
      localStorage.setItem('username', username);
      document.getElementById('login-form').style.display = 'none';
      document.getElementById('register-form').style.display = 'none';
    } else {
      const errorData = await response.json();
      alert(errorData.error || 'Грешка при најава.');
    }
  } catch (err) {
    console.error(err);
    alert('Серверска грешка.');
  }
}

// REGISTER FUNKCIJA
async function registerUser() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const email = document.getElementById('email').value;
  const address = document.getElementById('address').value;

  try {
    const response = await fetch('/users', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password, email, address })
    });

    if (response.ok) {
      alert('Успешна регистрација!');
      document.getElementById('register-form').reset();
    } else {
      const errorData = await response.json();
      alert(errorData.error || 'Грешка при регистрација.');
    }
  } catch (err) {
  console.error('Серверска грешка:', err);
  alert('Серверска грешка: ' + (err.message || 'Непозната грешка.'));
}

}


// prikazuvanje sekcija (Menuvacnica, Cenovnik, Lokacija, Za nas)
function showSection(sectionId) {
  document.getElementById('менувачница').style.display = 'none';
  document.getElementById('ценовник').style.display = 'none';
  document.getElementById('локација').style.display = 'none';
  document.getElementById(sectionId).style.display = 'block';

  if (sectionId === 'ценовник') {
    fetchCryptoPrices();
  }
}

// Funkcija za konverzija kriptovaluti
async function convertCurrency() {
  let amount = document.getElementById('amount').value;
  let from = document.getElementById('fromCurrency').value;
  let to = document.getElementById('toCurrency').value;

  if (!amount) {
    alert("Vnesete iznos za konverzija.");
    return;
  }

  let cryptoIds = {
    btc: "bitcoin",
    eth: "ethereum",
    ada: "cardano",
    sol: "solana",
    xrp: "ripple",
    ltc: "litecoin",
    dot: "polkadot",
    doge: "dogecoin"
  };

  let fromId = cryptoIds[from];

  if (!fromId) {
    alert("Погрешен избор на криптовалута");
    return;
  }

  let url = `https://api.coingecko.com/api/v3/simple/price?ids=${fromId}&vs_currencies=${to}`;

  try {
    let response = await fetch(url);
    let data = await response.json();

    if (!data[fromId] || !data[fromId][to]) {
      throw new Error(`Нема податоци за ${fromId} во валутата ${to.toUpperCase()}`);
    }

    let rate = data[fromId][to];
    let convertedAmount = amount * rate;

    document.getElementById('result').innerText =
      `${amount} ${from.toUpperCase()} = ${convertedAmount.toFixed(2)} ${to.toUpperCase()}`;

  } catch (error) {
    console.error("Се појави грешка при преземањето на податоците.:", error);
    alert(`Се појави грешка: ${error.message}`);
  }
}

// Funkcija za kupuvanje kriptovaluti
function buyCrypto(coin) {
  let amount = prompt(`Колку ${coin.toUpperCase()} сакате да купите?`);
  if (amount && !isNaN(amount) && amount > 0) {
    alert(`Успешно купивте ${amount} ${coin.toUpperCase()}.`);
    saveTransaction('Купување', coin, amount);
  } else {
    alert("Внесете валиден износ!");
  }
}

// Funkcija za prodavanje kriptovaluti
function sellCrypto(coin) {
  let amount = prompt(`Колку ${coin.toUpperCase()} сакате да продадете?`);
  if (amount && !isNaN(amount) && amount > 0) {
    alert(`Успешно продадовте ${amount} ${coin.toUpperCase()}.`);
    saveTransaction('Распродажба', coin, amount);
  } else {
    alert("Внесете валиден износ");
  }
}

// Čuvanje transakcija u Local Storage
function saveTransaction(type, coin, amount) {
  let transactions = JSON.parse(localStorage.getItem('transactions')) || [];
  let newTransaction = {
    type: type,
    coin: coin.toUpperCase(),
    amount: amount,
    time: new Date().toLocaleString()
  };

  transactions.push(newTransaction);
  localStorage.setItem('transactions', JSON.stringify(transactions));

  renderTransactionHistory(); // azuriranje tabela so transakcija
}

// Prikaz istorije transakcija
function renderTransactionHistory() {
  let transactions = JSON.parse(localStorage.getItem('transactions')) || [];
  let tableBody = document.getElementById('transaction-history');
  tableBody.innerHTML = '';

  transactions.forEach(transaction => {
    tableBody.innerHTML += `
      <tr>
        <td>${transaction.type}</td>
        <td>${transaction.coin}</td>
        <td>${transaction.amount}</td>
        <td>${transaction.time}</td>
      </tr>
    `;
  });
}

renderTransactionHistory(); //  prikaz transakcija pri vcituvanje str

// Function to fetch and display cryptocurrency prices
async function fetchCryptoPrices() {
  const url = 'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,cardano,solana,ripple,litecoin,polkadot,dogecoin&vs_currencies=usd,eur';
  try {
    const response = await fetch(url);
    const data = await response.json();

    const cryptoPrices = document.getElementById('crypto-prices');
    cryptoPrices.innerHTML = ''; // Cistenje data
    const cryptoIds = {
      bitcoin: 'Bitcoin (BTC)',
      ethereum: 'Ethereum (ETH)',
      cardano: 'Cardano (ADA)',
      solana: 'Solana (SOL)',
      ripple: 'Ripple (XRP)',
      litecoin: 'Litecoin (LTC)',
      polkadot: 'Polkadot (DOT)',
      dogecoin: 'Dogecoin (DOGE)'
    };

    for (const [key, value] of Object.entries(cryptoIds)) {
      const priceUsd = data[key].usd;
      const priceEur = data[key].eur;

      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${value}</td>
        <td>${priceUsd} USD / ${priceEur} EUR</td>
        <td><button onclick="buyCrypto('${key}')">Купи</button></td>
        <td><button onclick="sellCrypto('${key}')">Продај</button></td>
      `;
      cryptoPrices.appendChild(row);
    }
  } catch (error) {
    console.error('Грешка при преземање на цените на криптовалутите:', error);
  }
}

// Call fetchCryptoPrices when the "Cenovnik" section is shown
function showSection(sectionId) {
  document.getElementById('менувачница').style.display = 'none';
  document.getElementById('ценовник').style.display = 'none';
  document.getElementById('локација').style.display = 'none';
  document.getElementById('zaNas').style.display = 'none';
  document.getElementById(sectionId).style.display = 'block';

  if (sectionId === 'ценовник') {
    fetchCryptoPrices();
  }
}

async function getUserById(userId) {
  try {
    const response = await fetch(`/users/${userId}`);
    if (response.ok) {
      const user = await response.json();
      alert(`Корисник: ${user.username}, Email: ${user.email}, Address: ${user.address}`);
    } else {
      const errorData = await response.json();
      alert(errorData.message || 'Корисникот не е најден.');
    }
  } catch (err) {
    console.error(err);
    alert('Серверска грешка.');
  }
}

async function getAllUsers() {
  try {
    const response = await fetch('/users');
    if (response.ok) {
      const users = await response.json();
      let message = 'Корисници:\n';
      users.forEach(u => {
        message += `-  ${u.username} (${u.email})\n`;
        // ${u._id}:
      });
      alert(message);
    } else {
      alert('Грешка при добивање на корисници');
    }
  } catch (err) {
    console.error(err);
    alert('Серверска грешка');
  }
}

async function deleteUserFromInput() {
  const userId = document.getElementById('delete-user-id').value.trim();

  if (!userId) {
    alert('Внеси ID на корисникот.');
    return;
  }

  if (!confirm(`Дали си сигурен дека сакаш да го избришеш корисникот со ID: ${userId}?`)) return;

  try {
    const response = await fetch(`/users/${userId}`, { method: 'DELETE' });
    if (response.ok) {
      alert('Корисникот е избришан успешно.');
      document.getElementById('delete-user-id').value = '';
    } else {
      alert('Грешка при бришење.');
    }
  } catch (err) {
    console.error(err);
    alert('Серверска грешка.');
  }
}
function showSection(id) {
  const sections = document.querySelectorAll(".container"); // сите секции имаат класа container
  sections.forEach(section => section.style.display = "none"); // крие ги сите

  const selectedSection = document.getElementById(id);
  if (selectedSection) {
    selectedSection.style.display = "block"; // ја покажува само избраната
  }

  // Ако е "ценовник", повикај ја функцијата за да ги вчита цените
  if (id === "ценовник") {
    fetchCryptoPrices();
  }
}

// REGISTER FUNKCIJA
async function editUser() {
  const id = document.getElementById('edit-user-id').value;
  const username = document.getElementById('edit-username').value;
  const password = document.getElementById('edit-password').value;
  const email = document.getElementById('edit-email').value;
  const address = document.getElementById('edit-address').value;

  try {
    const response = await fetch(`/users/edit/${id}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password, email, address })
    });

    if (response.ok) {
      alert('Успешно ажурирање!');
      document.getElementById('edit-form').reset();
    } else {
      const errorData = await response.json();
      alert(errorData.error);
    }
  } catch (err) {
  console.error('Серверска грешка:', err);
  alert('Серверска грешка: ' + (err.message || 'Непозната грешка.'));
}
}
