const express = require('express');
const bodyParser = require('body-parser');
const connectDB = require('./db'); // MongoDB connection
const userController = require('./controllers/userController');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;


// Connect to MongoDB
connectDB();

// Middleware
app.use(bodyParser.json()); // или app.use(express.json())

// Static files (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.post('/login', userController.login);
app.post('/users', userController.createUser);
app.post('/users/edit/:id', userController.editUser);
app.get('/users/:id', userController.getUser);
app.delete('/users/:id', userController.deleteUser);
app.get('/users', userController.getAllUsers);

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
