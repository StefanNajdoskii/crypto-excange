const User = require('../models/User');

exports.login = async (req, res) => {
  const { username, password, email, address } = req.body;
  const user = await User.findOne({ username, password });
 
  if (!user) return res.status(401).json({ error: 'Невалиден корисник' });

  res.json({ message: 'Успешно логирање', user });
};
 
exports.createUser = async (req, res) => {
  const { username, password, email, address } = req.body;
 
  

    console.log("➡️ POST /users received body:", req.body);

  try {
    const newUser = await User.create({ username, password, email, address});
       console.log("✅ User created:", newUser);

    res.status(201).json(newUser);
  } catch (err) {
        console.error("❌ Error creating user:", err.message);

    res.status(400).json({ error: err.message });
  }
};
 
exports.getUser = async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ message: 'User not found' });
 
  res.json(user);
};
 
exports.deleteUser = async (req, res) => {
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) return res.status(404).json({ message: 'User not found' });
 
  res.json({ message: 'User deleted', user });
};
 
exports.getAllUsers = async (req, res) => {
  const users = await User.find();
  res.json(users);
};


exports.createUser = async (req, res) => {
  const { username, password, email, address } = req.body;

  console.log("➡️ POST /users received body:", req.body);

  try {
    // Проверка дали username постои
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      console.log("⚠️ Корисник со ова име веќе постои:", username);
      return res.status(400).json({ error: 'Корисничкото име веќе постои' });
    }

    const newUser = await User.create({ username, password, email, address });
    console.log("✅ User created:", newUser);

    res.status(201).json(newUser);
  } catch (err) {
    console.error("❌ Error creating user:", err.message);
    res.status(400).json({ error: err.message });
  }
};


// Update user by ID
exports.editUser = async (req, res) => {
  const userId = req.params.id;
  const updateData = req.body; // e.g. { username, email, address, password }

  try {
    const updatedUser = await User.findOneAndUpdate(
      { _id: userId },
      updateData,
      { new: true, runValidators: true } 
    );

    if (!updatedUser) {
      return res.status(404).json({ error: 'Корисникот не е пронајден' });
    }

    res.json(updatedUser);
  } catch (err) {
    console.error('Грешка при ажурирање на корисник:', err);
    res.status(500).json({ error: 'Серверска грешка' });
  }
};